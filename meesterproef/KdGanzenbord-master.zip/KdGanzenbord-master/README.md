# KdGanzenbord

Thomas:
view,
pionnen,
verplaatsing


Sander:
spelregels


Niels:
dobbelsteen,
beurten,
startscherm
