function changeBackgroundAndImage() {

    if (button1.innerHTML == 0 && button2.innerHTML == 0 && button3.innerHTML == 0) {
        image.src = "images/bg0.jpg";
        image1.src = "images/0.jpg";
      



    } else if (button1.innerHTML == 1 && button2.innerHTML == 1 && button3.innerHTML == 1) {
        image.src = "images/bg3.jpg";
        image1.src = "images/3.jpg";
    } else if (button1.innerHTML == 1 && button2.innerHTML == 1 || button1.innerHTML == 1 && button3.innerHTML == 1 || button2.innerHTML == 1 && button3.innerHTML == 1) {
        image.src = "images/bg2.jpg";
        image1.src = "images/2.jpg";
    } else {
        image.src = "images/bg1.jpg";
        image1.src = "images/1.jpg";
    }
}

function increaseValue(button) {
    var value = parseInt(button.innerHTML);
    if (value == 1) {
        value--;
    } else {
        value++;
    }
    button.innerHTML = value;
    changeBackgroundAndImage();
}

button1.addEventListener("click", function() {
    increaseValue(button1);
});

button2.addEventListener("click", function() {
    increaseValue(button2);
});

button3.addEventListener("click", function() {
    increaseValue(button3);
});